import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, OrbitControls, Stars } from "@react-three/drei";
import * as THREE from "three";
import "./styles.css";

const initialDesign = {
  name: "Starter Explorer",
  bodyLength: 3.2,
  bodyRadius: 0.32,
  nose: "Ogive",
  fins: 3,
  finSize: 0.72,
  bodyColor: "#f4f1ea",
  accentColor: "#e47d25",
  material: "Matte",
};

const components = [
  { name: "Explorer Body", type: "Structure", mass: "180 g", price: "$18", effect: "Main structural tube" },
  { name: "Ogive Nose Cone", type: "Aerodynamics", mass: "55 g", price: "$12", effect: "Streamlined forward section" },
  { name: "Fin Set — 3", type: "Stability", mass: "42 g", price: "$9", effect: "Adds aerodynamic stability" },
  { name: "Flight Computer", type: "Electronics", mass: "38 g", price: "$29", effect: "Educational sensor/data module" },
  { name: "Altimeter Sensor", type: "Electronics", mass: "8 g", price: "$14", effect: "Measures altitude for simulation" },
  { name: "Recovery Module", type: "Systems", mass: "70 g", price: "$16", effect: "Conceptual recovery system" },
];

function RocketModel({ design, interactive = true }) {
  const group = useRef();
  const bodyMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: design.bodyColor, roughness: design.material === "Gloss" ? 0.25 : 0.7, metalness: design.material === "Metal" ? 0.45 : 0.05
  }), [design.bodyColor, design.material]);
  const accentMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: design.accentColor, roughness: 0.5, metalness: 0.08
  }), [design.accentColor]);

  useFrame((_, delta) => {
    if (group.current && interactive) group.current.rotation.y += delta * 0.16;
  });

  const bodyHeight = design.bodyLength;
  const r = design.bodyRadius;
  const finCount = Math.max(3, Math.min(5, design.fins));

  return (
    <group ref={group} rotation={[0, 0, 0.04]}>
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[r, r * 1.02, bodyHeight, 48]} />
        <primitive object={bodyMat} attach="material" />
      </mesh>

      <mesh position={[0, bodyHeight / 2 + 0.47, 0]} rotation={[Math.PI, 0, 0]}>
        <coneGeometry args={[r * 1.02, 0.94, 48]} />
        <primitive object={bodyMat} attach="material" />
      </mesh>

      <mesh position={[0, -bodyHeight / 2 - 0.14, 0]}>
        <cylinderGeometry args={[r * 0.84, r * 0.9, 0.28, 40]} />
        <primitive object={accentMat} attach="material" />
      </mesh>

      <mesh position={[0, 0.02, 0]}>
        <torusGeometry args={[r * 1.01, 0.028, 10, 48]} />
        <primitive object={accentMat} attach="material" />
      </mesh>

      {Array.from({ length: finCount }).map((_, i) => {
        const a = (i / finCount) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.sin(a) * (r + design.finSize * 0.33), -bodyHeight * 0.29, Math.cos(a) * (r + design.finSize * 0.33)]}
            rotation={[0, a, 0]}>
            <boxGeometry args={[design.finSize * 0.65, design.finSize * 0.85, 0.07]} />
            <primitive object={accentMat} attach="material" />
          </mesh>
        );
      })}
    </group>
  );
}

function RocketViewer({ design, small = false }) {
  return (
    <Canvas camera={{ position: [4.5, 1.2, 5.2], fov: 38 }} dpr={[1, 1.5]}>
      <ambientLight intensity={1.1} />
      <directionalLight position={[4, 6, 4]} intensity={2.1} />
      <directionalLight position={[-4, 2, -3]} intensity={0.8} />
      <Environment preset="city" />
      {!small && <Stars radius={45} depth={20} count={700} factor={1.1} saturation={0} fade speed={0.2} />}
      <RocketModel design={design} interactive={!small} />
      <OrbitControls enablePan={false} minDistance={3} maxDistance={10} />
    </Canvas>
  );
}

function App() {
  const [page, setPage] = useState("home");
  const [dark, setDark] = useState(() => localStorage.getItem("aeroforge-theme") !== "light");
  const [design, setDesign] = useState(() => {
    try { return JSON.parse(localStorage.getItem("aeroforge-design")) || initialDesign; } catch { return initialDesign; }
  });
  const [aeroOpen, setAeroOpen] = useState(false);
  const [messages, setMessages] = useState([{ role: "aero", text: "Hi! I’m Aero. I can explain AeroForge concepts and help you understand your current design." }]);
  const [input, setInput] = useState("");
  const [simulation, setSimulation] = useState(false);

  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    localStorage.setItem("aeroforge-theme", dark ? "dark" : "light");
  }, [dark]);

  useEffect(() => {
    localStorage.setItem("aeroforge-design", JSON.stringify(design));
  }, [design]);

  const mass = 180 + 55 + (design.fins * 14) + 38;
  const cost = 18 + 12 + (design.fins * 3) + 29;
  const stability = design.fins >= 3 && design.bodyLength <= 4.2 ? "Good" : "Review";
  const estimatedAltitude = Math.round(420 + design.bodyLength * 80 - design.bodyRadius * 180 + design.fins * 10);

  const update = (key, value) => setDesign(d => ({ ...d, [key]: value }));

  function sendAero() {
    const text = input.trim();
    if (!text) return;
    setMessages(m => [...m, { role: "user", text }, {
      role: "aero",
      text: answerAero(text, { design, mass, cost, stability, estimatedAltitude })
    }]);
    setInput("");
  }

  const nav = [
    ["home", "Home"], ["forge", "Forge"], ["learn", "Learn"], ["components", "Components"],
    ["simulation", "Simulation"], ["flight", "Flight Computer"], ["projects", "Projects"], ["about", "About"]
  ];

  return (
    <div className="app">
      <header className="nav">
        <button className="brand" onClick={() => setPage("home")}>
          <span className="brand-mark">A</span>
          <span>AeroForge</span>
        </button>
        <nav>
          {nav.map(([id, label]) => <button key={id} className={page === id ? "active" : ""} onClick={() => setPage(id)}>{label}</button>)}
        </nav>
        <button className="theme" onClick={() => setDark(v => !v)} aria-label="Toggle theme">{dark ? "☼" : "☾"}</button>
      </header>

      {page === "home" && <Home go={setPage} design={design} />}
      {page === "forge" && <Forge design={design} update={update} mass={mass} cost={cost} stability={stability} estimatedAltitude={estimatedAltitude} />}
      {page === "learn" && <Learn go={setPage} />}
      {page === "components" && <Components add={() => setPage("forge")} />}
      {page === "simulation" && <Simulation design={design} simulation={simulation} setSimulation={setSimulation} altitude={estimatedAltitude} />}
      {page === "flight" && <FlightComputer />}
      {page === "projects" && <Projects design={design} open={() => setPage("forge")} />}
      {page === "about" && <About />}

      <button className="aero-fab" onClick={() => setAeroOpen(v => !v)}>
        <span className="astronaut">◉</span><span>Aero</span>
      </button>

      {aeroOpen && <div className="aero-panel">
        <div className="aero-head"><div><b>Aero</b><span>Friendly teacher</span></div><button onClick={() => setAeroOpen(false)}>×</button></div>
        <div className="messages">{messages.map((m, i) => <div key={i} className={"msg " + m.role}>{m.text}</div>)}</div>
        <div className="aero-input"><input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && sendAero()} placeholder="Ask Aero something..." /><button onClick={sendAero}>→</button></div>
      </div>}
    </div>
  );
}

function Home({ go, design }) {
  return <main className="home">
    <div className="home-copy">
      <div className="eyebrow">EDUCATIONAL ROCKET DESIGN LAB</div>
      <h1>Welcome to <span>AeroForge.</span></h1>
      <p>Design. Learn. Explore.</p>
      <div className="home-actions"><button className="primary" onClick={() => go("forge")}>Start Designing</button><button className="secondary" onClick={() => go("learn")}>Explore Learning</button></div>
      <div className="home-note"><i /> Your designs stay in this browser.</div>
    </div>
    <div className="hero-model"><RocketViewer design={design} /></div>
    <div className="hero-stats"><span><b>01</b> Build visually</span><span><b>02</b> Analyze automatically</span><span><b>03</b> Learn as you go</span></div>
  </main>;
}

function Forge({ design, update, mass, cost, stability, estimatedAltitude }) {
  return <main className="forge page">
    <section className="page-title"><div><div className="eyebrow">FORGE</div><h2>Shape your next design.</h2><p>You design it. AeroForge analyzes it.</p></div><input className="project-name" value={design.name} onChange={e => update("name", e.target.value)} /></section>
    <div className="forge-grid">
      <aside className="panel controls">
        <h3>Design</h3>
        <label>Body length <b>{design.bodyLength.toFixed(1)} m</b><input type="range" min="2" max="4.8" step="0.1" value={design.bodyLength} onChange={e => update("bodyLength", +e.target.value)} /></label>
        <label>Body radius <b>{design.bodyRadius.toFixed(2)} m</b><input type="range" min="0.2" max="0.48" step="0.01" value={design.bodyRadius} onChange={e => update("bodyRadius", +e.target.value)} /></label>
        <label>Fins <b>{design.fins}</b><input type="range" min="3" max="5" step="1" value={design.fins} onChange={e => update("fins", +e.target.value)} /></label>
        <label>Fin size <b>{design.finSize.toFixed(2)}</b><input type="range" min="0.45" max="1.0" step="0.01" value={design.finSize} onChange={e => update("finSize", +e.target.value)} /></label>
        <div className="field"><span>Body color</span><input type="color" value={design.bodyColor} onChange={e => update("bodyColor", e.target.value)} /></div>
        <div className="field"><span>Accent</span><input type="color" value={design.accentColor} onChange={e => update("accentColor", e.target.value)} /></div>
        <div className="field"><span>Finish</span><select value={design.material} onChange={e => update("material", e.target.value)}><option>Matte</option><option>Gloss</option><option>Metal</option></select></div>
      </aside>
      <section className="model-card"><div className="model-label">3D DESIGN VIEW <span>Drag to inspect • Scroll to zoom</span></div><RocketViewer design={design} /></section>
      <aside className="panel analysis">
        <div className="analysis-top"><h3>Analysis</h3><span className="live">LIVE</span></div>
        <Metric label="Estimated mass" value={`${mass} g`} />
        <Metric label="Estimated cost" value={`$${cost}`} />
        <Metric label="Stability" value={stability} good={stability === "Good"} />
        <Metric label="Simulation altitude" value={`${estimatedAltitude} m`} />
        <div className="warning"><b>Design check</b><p>{stability === "Good" ? "The current geometry looks balanced for this educational estimate." : "Some geometry deserves another look before simulation."}</p><button>Learn more →</button></div>
        <p className="disclaimer">Estimates are simplified educational models, not flight certification.</p>
      </aside>
    </div>
  </main>;
}
function Metric({ label, value, good }) { return <div className="metric"><span>{label}</span><b className={good ? "good" : ""}>{value}</b></div>; }

function Learn({ go }) {
  const lessons = [
    ["01", "Rocket Basics", "Parts, forces, motion, and the vocabulary you need to start."],
    ["02", "Aerodynamics", "How shape, drag, lift, and stability affect a vehicle."],
    ["03", "Structures", "Why materials, geometry, and mass distribution matter."],
    ["04", "Electronics", "Sensors, microcontrollers, data collection, and telemetry concepts."],
    ["05", "Flight Computers", "Understand how the electronic pieces fit together."],
    ["06", "Simulation", "Turn a design into data and learn what the numbers mean."]
  ];
  return <main className="page content"><div className="eyebrow">LEARN</div><h2>Learn the why behind the design.</h2><p className="lead">A structured path for beginners, with contextual explanations available while you build.</p><div className="lesson-grid">{lessons.map(x => <article className="lesson" key={x[0]}><span>{x[0]}</span><h3>{x[1]}</h3><p>{x[2]}</p><button onClick={() => go("forge")}>Open concept →</button></article>)}</div></main>;
}

function Components({ add }) {
  const [query, setQuery] = useState("");
  const shown = components.filter(c => (c.name + c.type).toLowerCase().includes(query.toLowerCase()));
  return <main className="page content"><div className="eyebrow">COMPONENTS</div><h2>Browse the building blocks.</h2><p className="lead">Browse → Select → Compare → Add to Design.</p><div className="component-toolbar"><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search components..." /><span>{shown.length} results</span></div><div className="component-grid">{shown.map(c => <article className="component" key={c.name}><span className="pill">{c.type}</span><h3>{c.name}</h3><p>{c.effect}</p><div className="specs"><span>Mass <b>{c.mass}</b></span><span>Price <b>{c.price}</b></span></div><button onClick={add}>Add to Design</button></article>)}</div></main>;
}

function Simulation({ design, simulation, setSimulation, altitude }) {
  const points = [0, .18, .39, .61, .79, .92, 1, .88, .64, .35, .1];
  return <main className="page content"><div className="eyebrow">SIMULATION</div><div className="sim-title"><div><h2>See the design become data.</h2><p className="lead">A simplified educational flight model for understanding trends.</p></div><button className="primary" onClick={() => setSimulation(v => !v)}>{simulation ? "Reset Simulation" : "Run Simulation"}</button></div>
    <div className="sim-grid"><div className={"flight-stage " + (simulation ? "running" : "")}><div className="horizon" /><div className="sim-rocket">▲</div><span className="alt-label">{simulation ? altitude : 0} m</span></div>
    <div className="panel results"><h3>Results</h3><Metric label="Peak altitude" value={`${altitude} m`} /><Metric label="Peak velocity" value={simulation ? "118 m/s" : "—"} /><Metric label="Peak acceleration" value={simulation ? "3.2 g" : "—"} /><Metric label="Flight time" value={simulation ? "19.6 s" : "—"} /><div className="chart"><div className="chart-line">{points.map((p,i)=><span key={i} style={{bottom:`${p*82}%`, left:`${i*9.5}%`}} />)}</div></div></div></div>
  </main>;
}

function FlightComputer() {
  const items = [["Microcontroller", "The small computer that coordinates sensor readings and logic."], ["Sensors", "Devices that measure physical quantities such as acceleration or altitude."], ["Data", "Measurements can be recorded and visualized to understand a flight."], ["Software", "Programs tell the electronics how to read, process, and store information."]];
  return <main className="page content"><div className="eyebrow">FLIGHT COMPUTER</div><h2>Understand the electronic system.</h2><p className="lead">A safe, educational view of how sensors, computing, software, and data work together.</p><div className="fc-layout"><div className="fc-diagram"><div className="node">SENSORS</div><div className="connector">↓</div><div className="node main">FLIGHT COMPUTER</div><div className="connector">↓</div><div className="node">DATA</div></div><div className="fc-list">{items.map(x => <article key={x[0]}><h3>{x[0]}</h3><p>{x[1]}</p></article>)}</div></div></main>;
}

function Projects({ design, open }) {
  return <main className="page content"><div className="eyebrow">PROJECTS</div><h2>Your designs, saved locally.</h2><p className="lead">No account required. This starter stores your current project in your browser.</p><div className="project-grid"><article className="project-card"><div className="mini-model"><RocketViewer design={design} small /></div><div className="project-info"><h3>{design.name}</h3><p>Starter project • Local browser storage</p><div><span>Mass {180 + 55 + design.fins*14 + 38} g</span><span>Stability Good</span></div><button onClick={open}>Open project →</button></div></article></div></main>;
}

function About() {
  return <main className="page content narrow"><div className="eyebrow">ABOUT</div><h2>A calm place to understand aerospace design.</h2><p className="lead">AeroForge is an educational rocket-design concept built around one principle: you design it, AeroForge analyzes it.</p><div className="about-card"><h3>Built for learning</h3><p>Complex engineering ideas are presented in approachable language, while calculations and assumptions remain visible enough to learn from.</p><h3>Privacy by default</h3><p>In this starter version, project data is stored locally in the browser. There are no accounts or cloud profiles.</p><h3>Educational only</h3><p>Simulation values are simplified estimates for learning and visualization. They should not be treated as real-world flight certification or safety guidance.</p></div></main>;
}

function answerAero(text, ctx) {
  const t = text.toLowerCase();
  if (t.includes("mass")) return `Your current educational estimate is ${ctx.mass} g. Mass affects how the simulation responds to forces and is one of the values I keep an eye on.`;
  if (t.includes("cost") || t.includes("price")) return `The current estimated component cost is $${ctx.cost}. Prices in this starter are example data, ready to be replaced by a supported data source later.`;
  if (t.includes("stability")) return `The current design is marked ${ctx.stability}. Stability is about how a vehicle tends to respond to disturbances; AeroForge can explain the concept without changing your design for you.`;
  if (t.includes("altitude") || t.includes("simulation")) return `The current simplified simulation estimates about ${ctx.estimatedAltitude} m peak altitude. This is an educational estimate, not a prediction for a real vehicle.`;
  if (t.includes("fin")) return `You currently have ${ctx.design.fins} fins. In the educational model, fins contribute to aerodynamic stability and add mass.`;
  return `For this project, I can explain the current design, analysis values, or AeroForge concepts. Try asking “Why is stability ${ctx.stability}?” or “What affects mass?”`;
}

createRoot(document.getElementById("root")).render(<App />);
