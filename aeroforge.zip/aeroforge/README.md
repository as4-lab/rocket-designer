# AeroForge

**Design. Learn. Explore.**

An educational rocket-design platform: build a rocket in **Forge**, watch it update
live in 3D, get plain-language engineering analysis, browse real components, run a
flight simulation, and learn the concepts behind all of it. No accounts — everything
is saved locally in your browser.

## Running it

```bash
npm install
npm run dev
```

Then open the printed local URL (usually `http://localhost:5173`).

```bash
npm run build     # production build to dist/
npm run preview   # preview the production build locally
```

## What's implemented

This is Phase 1–4 of the project roadmap, built out fully, plus working (if
intentionally simplified) versions of Phases 5–8:

- **Foundation** — React + Vite, routing, light/dark mode, responsive layout, homepage.
- **Forge** — a procedural 3D rocket (Three.js / React Three Fiber) that updates live
  as you edit nose cone, body tube, fins, motor, avionics, color and finish. Local
  project saving.
- **Analysis** — mass and cost rollups, plus a genuine simplified **Barrowman
  stability estimate** (center of pressure vs. center of gravity, reported in
  calibers), with an explanatory warning card when margin is outside the 1–2.5
  caliber range.
- **Components** — a searchable, filterable, sortable catalog with a detail panel
  and one-click "add to design."
- **Learn** — a structured six-step learning path, plus contextual lessons linked
  directly from component details and Forge warnings.
- **Simulation** — Version 1 of the roadmap: thrust, gravity, and burning propellant
  mass, charted as altitude/velocity/acceleration over time. Drag and environmental
  factors are left for Version 2+ as planned.
- **Flight Computer** — educational concept cards plus an interactive avionics
  picker shared with Forge.
- **Aero** — a floating assistant with a small local knowledge base that's aware of
  your current project's mass, cost, and stability. It does **not** call an external
  AI API yet (see below).

## Wiring up a real AI backend for Aero

Aero currently answers from `src/utils/aeroKnowledge.js`. That file already builds
the project-context payload (`buildAeroPrompt`) described in the original brief:

```
Aero UI → AeroForge project context → AI backend/API layer → AI model
```

To connect a real model:

1. Add a small backend/serverless endpoint that holds your API key (**never** put an
   API key in this frontend or commit it to the repo).
2. Have that endpoint accept `{ question, project }` (see `buildAeroPrompt`) and
   return a reply.
3. Swap the body of `answerAero()` in `src/utils/aeroKnowledge.js` for a `fetch()`
   call to that endpoint. The chat UI (`src/components/AeroChat.jsx`) doesn't need
   to change.

## What's intentionally not built yet

- Full appearance customization (decals/markings/material swaps) — currently color
  and matte/glossy finish only.
- Simulation Versions 2–4 (drag, environmental factors, more detailed analysis).
- Automatic/live component pricing — the catalog in `src/data/components.js` is
  manually maintained data with a `priceSource`/`priceDate` field ready for a future
  pricing integration.
- Export/backup of local data (explicitly out of scope per the brief).

## Stack

React 18, Vite, React Router, Three.js via `@react-three/fiber` + `@react-three/drei`,
Recharts, plain CSS with a token-based theme (see `src/styles/global.css`).
