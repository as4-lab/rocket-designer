import React from "react";
import { Link, useParams } from "react-router-dom";
import { LEARNING_PATH, LESSONS } from "../data/lessons.js";
import "./Learn.css";

export default function Learn() {
  const { lessonId } = useParams();
  const lesson = lessonId ? LESSONS[lessonId] : null;

  if (lessonId && lesson) {
    return (
      <div className="learn-page container">
        <Link to="/learn" className="learn-back">
          ← Back to Learn
        </Link>
        <h1>{lesson.title}</h1>
        {lesson.body.map((p, i) => (
          <p key={i} className="learn-paragraph">
            {p}
          </p>
        ))}
      </div>
    );
  }

  return (
    <div className="learn-page container">
      <div className="components-header">
        <h1>Learn</h1>
        <p>A structured path from zero to a working understanding of rocket design — or jump in wherever you need.</p>
      </div>

      <div className="learn-path">
        {LEARNING_PATH.map((step, i) => (
          <Link key={step.id} to={`/learn/${step.id}`} className="learn-step card">
            <span className="learn-step-index mono">{String(i + 1).padStart(2, "0")}</span>
            <div>
              <h3>{step.title}</h3>
              <p>{step.summary}</p>
            </div>
            {i < LEARNING_PATH.length - 1 && <div className="learn-step-connector" />}
          </Link>
        ))}
      </div>

      <div className="learn-note card">
        <p>
          You can also learn while designing — open any component in the{" "}
          <Link to="/components">Components</Link> section or a warning in{" "}
          <Link to="/forge">Forge</Link> to jump straight to the relevant concept.
        </p>
      </div>
    </div>
  );
}
