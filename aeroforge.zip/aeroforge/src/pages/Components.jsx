import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ALL_COMPONENTS, CATEGORY_LABELS } from "../data/components.js";
import { useProject } from "../context/ProjectContext.jsx";
import "./Components.css";

const CATEGORIES = ["all", "nose", "body", "fins", "motor", "avionics"];
const SORTS = [
  { id: "name", label: "Name" },
  { id: "price", label: "Price" },
  { id: "mass", label: "Mass" },
];

function priceOf(c) {
  return c.price ?? c.pricePerCm ?? 0;
}
function massOf(c) {
  return c.massG ?? c.massPerCmG ?? 0;
}

export default function ComponentsPage() {
  const { design, updateDesign } = useProject();
  const [category, setCategory] = useState("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("name");
  const [selectedId, setSelectedId] = useState(null);

  const filtered = useMemo(() => {
    let list = ALL_COMPONENTS;
    if (category !== "all") list = list.filter((c) => c.category === category);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter((c) => c.name.toLowerCase().includes(q) || c.material?.toLowerCase().includes(q));
    }
    const sorted = [...list].sort((a, b) => {
      if (sort === "price") return priceOf(a) - priceOf(b);
      if (sort === "mass") return massOf(a) - massOf(b);
      return a.name.localeCompare(b.name);
    });
    return sorted;
  }, [category, query, sort]);

  const selected = ALL_COMPONENTS.find((c) => c.id === selectedId) ?? filtered[0];

  const currentlyInstalled = selected && design[selected.category]?.id === selected.id;

  const addToDesign = () => {
    if (!selected) return;
    updateDesign({ [selected.category]: selected });
  };

  return (
    <div className="components-page container">
      <div className="components-header">
        <h1>Components</h1>
        <p>Browse, compare, and drop parts straight into your current design.</p>
      </div>

      <div className="components-toolbar">
        <input
          className="components-search"
          placeholder="Search components…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <div className="components-cats">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              className={category === c ? "active" : ""}
              onClick={() => setCategory(c)}
            >
              {c === "all" ? "All" : CATEGORY_LABELS[c]}
            </button>
          ))}
        </div>
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          {SORTS.map((s) => (
            <option key={s.id} value={s.id}>
              Sort by {s.label}
            </option>
          ))}
        </select>
      </div>

      <div className="components-body">
        <div className="components-grid">
          {filtered.map((c) => (
            <button
              key={c.id}
              className={`component-card ${selected?.id === c.id ? "component-card-active" : ""}`}
              onClick={() => setSelectedId(c.id)}
            >
              <span className="pill">{CATEGORY_LABELS[c.category]}</span>
              <div className="component-card-name">{c.name}</div>
              <div className="component-card-meta mono">
                {c.price !== undefined ? `$${c.price.toFixed(2)}` : `$${c.pricePerCm.toFixed(2)}/cm`}
                {" · "}
                {c.massG !== undefined ? `${c.massG} g` : `${c.massPerCmG} g/cm`}
              </div>
            </button>
          ))}
          {filtered.length === 0 && <p>No components match that search.</p>}
        </div>

        {selected && (
          <aside className="component-detail card">
            <span className="pill">{CATEGORY_LABELS[selected.category]}</span>
            <h2>{selected.name}</h2>
            <p>{selected.blurb}</p>

            <div className="component-specs">
              {selected.material && (
                <div>
                  <span>Material</span>
                  <strong>{selected.material}</strong>
                </div>
              )}
              {selected.massG !== undefined && (
                <div>
                  <span>Mass</span>
                  <strong className="mono">{selected.massG} g</strong>
                </div>
              )}
              {selected.massPerCmG !== undefined && (
                <div>
                  <span>Mass</span>
                  <strong className="mono">{selected.massPerCmG} g/cm</strong>
                </div>
              )}
              {selected.avgThrustN !== undefined && (
                <div>
                  <span>Avg. thrust</span>
                  <strong className="mono">{selected.avgThrustN} N</strong>
                </div>
              )}
              {selected.burnTimeS !== undefined && (
                <div>
                  <span>Burn time</span>
                  <strong className="mono">{selected.burnTimeS} s</strong>
                </div>
              )}
              {selected.totalImpulseNs !== undefined && (
                <div>
                  <span>Total impulse</span>
                  <strong className="mono">{selected.totalImpulseNs} N·s</strong>
                </div>
              )}
            </div>

            <div className="component-price">
              <div>
                <span>Price</span>
                <strong className="mono">
                  {selected.price !== undefined ? `$${selected.price.toFixed(2)}` : `$${selected.pricePerCm.toFixed(2)}/cm`}
                </strong>
              </div>
              <div className="component-price-meta">
                {selected.priceSource} · as of {selected.priceDate}
              </div>
            </div>

            <button className="btn btn-primary" onClick={addToDesign} disabled={currentlyInstalled}>
              {currentlyInstalled ? "Currently installed" : "Add to design"}
            </button>

            <Link to={`/learn/${selected.learnId}`} className="component-learn-link">
              Learn how this affects your rocket →
            </Link>
          </aside>
        )}
      </div>
    </div>
  );
}
