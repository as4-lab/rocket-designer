import React, { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import { useProject } from "../context/ProjectContext.jsx";
import { simulateFlight } from "../utils/simulation.js";
import "./Simulation.css";

export default function Simulation() {
  const { design, analysis } = useProject();
  const [result, setResult] = useState(null);

  const run = () => {
    setResult(simulateFlight(design, analysis.mass));
  };

  return (
    <div className="simulation-page container">
      <div className="components-header">
        <h1>Simulation</h1>
        <p>
          Version 1: thrust, gravity, and changing mass as propellant burns. Drag and
          environmental factors arrive in later versions of AeroForge.
        </p>
      </div>

      <div className="sim-run-row">
        <button className="btn btn-primary" onClick={run}>
          Simulate "{design.name}"
        </button>
        {result && (
          <div className="sim-summary mono">
            <span>Apogee {Math.round(result.apogee.altitude)} m</span>
            <span>Max velocity {result.maxVelocity.toFixed(1)} m/s</span>
            <span>Flight time {result.flightTime.toFixed(1)} s</span>
          </div>
        )}
      </div>

      {result && (
        <div className="sim-charts">
          <ChartCard title="Altitude (m)" data={result.samples} dataKey="altitude" />
          <ChartCard title="Velocity (m/s)" data={result.samples} dataKey="velocity" />
          <ChartCard title="Acceleration (m/s²)" data={result.samples} dataKey="acceleration" />
        </div>
      )}

      {!result && (
        <div className="sim-empty card">
          <p>Run a simulation to see altitude, velocity, and acceleration over time for your current design.</p>
        </div>
      )}
    </div>
  );
}

function ChartCard({ title, data, dataKey }) {
  return (
    <div className="sim-chart-card card">
      <h4>{title}</h4>
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -12 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
          <XAxis dataKey="t" tick={{ fontSize: 11 }} stroke="var(--text-faint)" unit="s" />
          <YAxis tick={{ fontSize: 11 }} stroke="var(--text-faint)" />
          <Tooltip
            contentStyle={{
              background: "var(--bg-elevated)",
              border: "1px solid var(--border)",
              borderRadius: 8,
              fontSize: 12,
            }}
          />
          <Line type="monotone" dataKey={dataKey} stroke="var(--accent-500, #c97d45)" dot={false} strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
