import React from "react";
import { Link } from "react-router-dom";
import RocketScene from "../three/RocketScene.jsx";
import { useProject } from "../context/ProjectContext.jsx";
import "./Home.css";

export default function Home() {
  const { design } = useProject();

  return (
    <div className="home">
      <div className="home-canvas">
        <RocketScene design={design} interactive={false} spin />
      </div>

      <div className="home-scrim" />

      <div className="home-content container">
        <p className="eyebrow">AEROFORGE</p>
        <h1 className="home-title">
          Welcome to AeroForge.
          <br />
          Design. Learn. Explore.
        </h1>
        <p className="home-sub">
          Start from a working rocket, tweak it yourself, and let AeroForge explain the
          engineering behind every change — no rocketry background required.
        </p>
        <div className="home-actions">
          <Link to="/forge" className="btn btn-primary">
            Start Designing
          </Link>
          <Link to="/learn" className="btn btn-secondary">
            Explore Learning
          </Link>
        </div>
      </div>
    </div>
  );
}
