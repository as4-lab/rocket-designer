import React, { useState } from "react";
import { Link } from "react-router-dom";
import RocketScene from "../three/RocketScene.jsx";
import { useProject } from "../context/ProjectContext.jsx";
import { NOSE_CONES, BODY_TUBES, FIN_SETS, MOTORS, AVIONICS } from "../data/components.js";
import "./Forge.css";

const PARTS = [
  { key: "nose", label: "Nose" },
  { key: "body", label: "Body" },
  { key: "fins", label: "Fins" },
  { key: "motor", label: "Motor" },
  { key: "avionics", label: "Avionics" },
  { key: "finish", label: "Finish" },
];

function stabilityWarning(stability) {
  if (stability.rating === "ideal") return null;
  const copy = {
    unstable: {
      title: "Potential stability issue",
      body: "Your current configuration may have insufficient stability.",
      why: "The center of pressure is at or ahead of the center of gravity, so aerodynamic forces won't reliably push the rocket back into straight flight.",
      fix: "Try a larger fin set, a lighter/shorter nose cone, or moving mass toward the tail.",
    },
    marginal: {
      title: "Stability margin is tight",
      body: "Your rocket is technically stable, but with very little margin.",
      why: "The center of pressure is only just behind the center of gravity — under 1 body diameter of separation.",
      fix: "A slightly larger fin set would add margin for wind and imperfect building tolerances.",
    },
    overstable: {
      title: "Stability margin is very high",
      body: "Your rocket has more stability margin than it typically needs.",
      why: "A large gap between center of pressure and center of gravity makes the rocket 'weathercock' strongly into any wind.",
      fix: "Slightly smaller fins would loosen this up and can improve altitude.",
    },
  };
  return copy[stability.rating];
}

export default function Forge() {
  const { design, updateDesign, resetDesign, analysis, save } = useProject();
  const [activePart, setActivePart] = useState("nose");
  const [savedNotice, setSavedNotice] = useState(false);

  const warning = stabilityWarning(analysis.stability);

  const handleSave = () => {
    save();
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2200);
  };

  return (
    <div className="forge">
      <aside className="forge-parts">
        <input
          className="forge-name-input"
          value={design.name}
          onChange={(e) => updateDesign({ name: e.target.value })}
          aria-label="Rocket name"
        />

        <div className="forge-parts-list">
          {PARTS.map((p) => (
            <button
              key={p.key}
              className={`forge-part-btn ${activePart === p.key ? "forge-part-btn-active" : ""}`}
              onClick={() => setActivePart(p.key)}
            >
              {p.label}
            </button>
          ))}
        </div>

        <div className="forge-part-editor">
          {activePart === "nose" && (
            <>
              <label>Nose cone</label>
              <select
                value={design.nose.id}
                onChange={(e) => updateDesign({ nose: NOSE_CONES.find((n) => n.id === e.target.value) })}
              >
                {NOSE_CONES.map((n) => (
                  <option key={n.id} value={n.id}>
                    {n.name}
                  </option>
                ))}
              </select>
              <p className="forge-hint">{design.nose.blurb}</p>
            </>
          )}

          {activePart === "body" && (
            <>
              <label>Body tube</label>
              <select
                value={design.body.id}
                onChange={(e) => updateDesign({ body: BODY_TUBES.find((b) => b.id === e.target.value) })}
              >
                {BODY_TUBES.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
              <label>Body length: {design.bodyLengthCm} cm</label>
              <input
                type="range"
                min={20}
                max={70}
                value={design.bodyLengthCm}
                onChange={(e) => updateDesign({ bodyLengthCm: Number(e.target.value) })}
              />
              <p className="forge-hint">{design.body.blurb}</p>
            </>
          )}

          {activePart === "fins" && (
            <>
              <label>Fin set</label>
              <select
                value={design.fins.id}
                onChange={(e) => updateDesign({ fins: FIN_SETS.find((f) => f.id === e.target.value) })}
              >
                {FIN_SETS.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
              <label>Number of fins</label>
              <div className="forge-segmented">
                {[3, 4].map((n) => (
                  <button
                    key={n}
                    className={design.finCount === n ? "active" : ""}
                    onClick={() => updateDesign({ finCount: n })}
                  >
                    {n}
                  </button>
                ))}
              </div>
              <p className="forge-hint">{design.fins.blurb}</p>
            </>
          )}

          {activePart === "motor" && (
            <>
              <label>Motor</label>
              <select
                value={design.motor.id}
                onChange={(e) => updateDesign({ motor: MOTORS.find((m) => m.id === e.target.value) })}
              >
                {MOTORS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} — class {m.impulseClass}
                  </option>
                ))}
              </select>
              <p className="forge-hint">{design.motor.blurb}</p>
            </>
          )}

          {activePart === "avionics" && (
            <>
              <label>Avionics</label>
              <select
                value={design.avionics.id}
                onChange={(e) => updateDesign({ avionics: AVIONICS.find((a) => a.id === e.target.value) })}
              >
                {AVIONICS.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
              <p className="forge-hint">{design.avionics.blurb}</p>
            </>
          )}

          {activePart === "finish" && (
            <>
              <label>Paint color</label>
              <input
                type="color"
                value={design.color}
                onChange={(e) => updateDesign({ color: e.target.value })}
              />
              <label>Finish</label>
              <div className="forge-segmented">
                {["matte", "glossy"].map((f) => (
                  <button
                    key={f}
                    className={design.finish === f ? "active" : ""}
                    onClick={() => updateDesign({ finish: f })}
                  >
                    {f}
                  </button>
                ))}
              </div>
              <p className="forge-hint">Full decals, markings, and material finishes are on the AeroForge roadmap.</p>
            </>
          )}
        </div>

        <div className="forge-parts-footer">
          <button className="btn btn-secondary" onClick={resetDesign}>
            Reset
          </button>
          <button className="btn btn-primary" onClick={handleSave}>
            {savedNotice ? "Saved ✓" : "Save Project"}
          </button>
        </div>
      </aside>

      <div className="forge-viewport">
        <RocketScene design={design} interactive spin={false} />
      </div>

      <aside className="forge-analysis">
        <h3>Analysis</h3>

        <div className="forge-metric">
          <span>Mass</span>
          <strong className="mono">{Math.round(analysis.mass.totalG)} g</strong>
        </div>
        <div className="forge-metric">
          <span>Cost</span>
          <strong className="mono">${analysis.cost.totalUSD.toFixed(2)}</strong>
        </div>
        <div className="forge-metric">
          <span>Stability</span>
          <strong className="mono">{analysis.stability.marginCalibers.toFixed(2)} cal</strong>
        </div>
        <div className="forge-metric">
          <span>Thrust : Weight</span>
          <strong className="mono">{analysis.stability.thrustToWeightRatio} : 1</strong>
        </div>

        {warning && (
          <div className="forge-warning">
            <div className="forge-warning-title">⚠ {warning.title}</div>
            <p>{warning.body}</p>
            <p>
              <strong>Why?</strong> {warning.why}
            </p>
            <p>
              <strong>Consider</strong> {warning.fix}
            </p>
            <Link to={`/learn/aerodynamics-fins`} className="forge-warning-link">
              Learn more →
            </Link>
          </div>
        )}

        <Link to="/simulation" className="btn btn-primary forge-simulate-btn">
          Simulate
        </Link>
      </aside>
    </div>
  );
}
