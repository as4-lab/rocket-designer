import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { loadProjects, deleteProject } from "../utils/storage.js";
import { useProject } from "../context/ProjectContext.jsx";
import { runAnalysis } from "../utils/analysis.js";
import StaticRocketPreview from "../components/StaticRocketPreview.jsx";
import "./Projects.css";

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const { loadDesign } = useProject();
  const navigate = useNavigate();

  useEffect(() => {
    setProjects(loadProjects());
  }, []);

  const open = (project) => {
    loadDesign(project);
    navigate("/forge");
  };

  const remove = (e, id) => {
    e.stopPropagation();
    deleteProject(id);
    setProjects(loadProjects());
  };

  return (
    <div className="projects-page container">
      <div className="components-header">
        <h1>Projects</h1>
        <p>Everything here is saved locally in this browser — nothing is uploaded anywhere.</p>
      </div>

      {projects.length === 0 ? (
        <div className="projects-empty card">
          <p>No saved projects yet. Design something in Forge and hit "Save Project".</p>
        </div>
      ) : (
        <div className="projects-grid">
          {projects
            .slice()
            .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
            .map((project) => {
              const analysis = runAnalysis(project);
              return (
                <button key={project.id} className="project-card card" onClick={() => open(project)}>
                  <div className="project-preview">
                    <StaticRocketPreview design={project} />
                  </div>
                  <div className="project-info">
                    <h3>{project.name}</h3>
                    <p className="project-date">
                      Updated {new Date(project.updatedAt).toLocaleDateString()}
                    </p>
                    <div className="project-stats mono">
                      <span>{Math.round(analysis.mass.totalG)} g</span>
                      <span>${analysis.cost.totalUSD.toFixed(2)}</span>
                      <span>{analysis.stability.marginCalibers.toFixed(1)} cal</span>
                    </div>
                  </div>
                  <button className="project-delete btn-ghost" onClick={(e) => remove(e, project.id)}>
                    Delete
                  </button>
                </button>
              );
            })}
        </div>
      )}
    </div>
  );
}
