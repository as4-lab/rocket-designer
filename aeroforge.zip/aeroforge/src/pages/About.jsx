import React from "react";
import "./About.css";

const PRINCIPLES = [
  { title: "Beginner-friendly", body: "Someone who knows very little about rocketry should still be able to use it." },
  { title: "Engineering-focused", body: "Calculations aim to use real engineering principles wherever practical." },
  { title: "Explain instead of hiding", body: "If AeroForge produces a result or a warning, it explains why." },
  { title: "You stay in control", body: "AeroForge never silently changes your design." },
  { title: "Lightweight", body: "The 3D experience looks detailed without being unnecessarily heavy." },
  { title: "Comfortable", body: "Soft, calm, and easy on the eyes — even during long design sessions." },
];

export default function About() {
  return (
    <div className="about-page container">
      <div className="components-header">
        <p className="eyebrow">ABOUT</p>
        <h1>Simple to use. Serious about the engineering.</h1>
        <p className="about-lede">
          AeroForge is an educational rocket-design platform. You start with a working default
          rocket, tweak it, and AeroForge analyzes the result — explaining the "why" behind every
          number instead of just handing you a pass or fail.
        </p>
      </div>

      <div className="about-principles">
        {PRINCIPLES.map((p) => (
          <div key={p.title} className="card about-principle">
            <h3>{p.title}</h3>
            <p>{p.body}</p>
          </div>
        ))}
      </div>

      <div className="card about-data">
        <h3>Your data</h3>
        <p>
          AeroForge doesn't use accounts. Your designs, learning progress, and preferences are
          stored locally in this browser only. If you clear browser storage or switch devices,
          that data won't carry over — there's no export or backup step yet, so it's worth keeping
          that in mind for anything you'd hate to lose.
        </p>
      </div>
    </div>
  );
}
