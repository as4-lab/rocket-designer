import React from "react";
import { Link } from "react-router-dom";
import { AVIONICS } from "../data/components.js";
import { useProject } from "../context/ProjectContext.jsx";
import "./FlightComputer.css";

const CONCEPTS = [
  { title: "Microcontroller", body: "The small onboard computer that reads sensors and logs or reacts to data during flight." },
  { title: "Sensors", body: "Barometric pressure sensors measure altitude; accelerometers measure acceleration; GPS modules track position." },
  { title: "Telemetry", body: "Sending flight data down to the ground in real time, instead of only recovering it after landing." },
  { title: "Software", body: "The logic that decides what to record, and on more advanced boards, when to fire recovery charges." },
];

export default function FlightComputer() {
  const { design, updateDesign } = useProject();

  return (
    <div className="fc-page container">
      <div className="components-header">
        <h1>Flight Computer</h1>
        <p>How rockets carry, and use, onboard electronics — and a simple configuration for your current design.</p>
      </div>

      <section className="fc-section">
        <h2>The building blocks</h2>
        <div className="fc-concepts">
          {CONCEPTS.map((c) => (
            <div key={c.title} className="fc-concept card">
              <h3>{c.title}</h3>
              <p>{c.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="fc-section">
        <h2>Configure your avionics</h2>
        <p>This selection is shared with Forge — changing it here updates your current project.</p>

        <div className="fc-config">
          {AVIONICS.map((a) => (
            <button
              key={a.id}
              className={`fc-avionics-card card ${design.avionics.id === a.id ? "fc-avionics-active" : ""}`}
              onClick={() => updateDesign({ avionics: a })}
            >
              <h4>{a.name}</h4>
              <p>{a.blurb}</p>
              <div className="fc-avionics-meta mono">
                {a.massG} g · ${a.price.toFixed(2)}
              </div>
            </button>
          ))}
        </div>

        {design.avionics.id !== "avionics-none" && (
          <div className="fc-diagram card">
            <div className="fc-diagram-node">Sensor</div>
            <div className="fc-diagram-line" />
            <div className="fc-diagram-node fc-diagram-node-main">{design.avionics.name}</div>
            <div className="fc-diagram-line" />
            <div className="fc-diagram-node">Onboard memory</div>
          </div>
        )}

        <Link to="/learn/electronics-flight-computers" className="component-learn-link">
          Learn more about flight computers →
        </Link>
      </section>
    </div>
  );
}
