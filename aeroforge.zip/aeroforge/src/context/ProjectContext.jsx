import React, { createContext, useContext, useMemo, useState, useCallback } from "react";
import { NOSE_CONES, BODY_TUBES, FIN_SETS, MOTORS, AVIONICS } from "../data/components.js";
import { runAnalysis } from "../utils/analysis.js";
import { saveProject as persistProject } from "../utils/storage.js";

const ProjectContext = createContext(null);

export function defaultDesign() {
  return {
    id: `rocket-${Date.now()}`,
    name: "Untitled Rocket",
    nose: NOSE_CONES[1], // ogive
    body: BODY_TUBES[1], // BT-60
    bodyLengthCm: 35,
    fins: FIN_SETS[1], // medium plywood
    finCount: 3,
    motor: MOTORS[1], // C6-5
    avionics: AVIONICS[0], // none
    color: "#c97d45",
    finish: "matte",
    createdAt: null,
    updatedAt: null,
  };
}

export function ProjectProvider({ children }) {
  const [design, setDesign] = useState(defaultDesign);

  const updateDesign = useCallback((patch) => {
    setDesign((d) => ({ ...d, ...patch }));
  }, []);

  const loadDesign = useCallback((newDesign) => {
    setDesign(newDesign);
  }, []);

  const resetDesign = useCallback(() => {
    setDesign(defaultDesign());
  }, []);

  const analysis = useMemo(() => runAnalysis(design), [design]);

  const save = useCallback(() => {
    const saved = persistProject(design);
    setDesign(saved);
    return saved;
  }, [design]);

  const value = { design, updateDesign, loadDesign, resetDesign, analysis, save };

  return <ProjectContext.Provider value={value}>{children}</ProjectContext.Provider>;
}

export function useProject() {
  const ctx = useContext(ProjectContext);
  if (!ctx) throw new Error("useProject must be used within ProjectProvider");
  return ctx;
}
