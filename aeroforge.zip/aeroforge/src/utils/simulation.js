// Version 1 simulation, per the AeroForge roadmap: altitude, velocity,
// acceleration and flight time from thrust, gravity, and changing mass as
// propellant burns. Drag and environmental factors are intentionally left
// for Version 2+ so the model stays easy to reason about for beginners.

const G = 9.81;
const DT = 0.02;

export function simulateFlight(design, massBreakdown) {
  const { motor } = design;
  const dryMassKg = (massBreakdown.totalG - motor.propellantMassG) / 1000;
  const propellantMassKg = motor.propellantMassG / 1000;

  let t = 0;
  let altitude = 0;
  let velocity = 0;
  const samples = [];
  let apogee = { t: 0, altitude: 0 };
  let maxVelocity = 0;
  let maxAcceleration = 0;
  let burnoutSample = null;

  const maxT = 60;

  while (t <= maxT) {
    const burning = t <= motor.burnTimeS;
    const massKg = burning
      ? dryMassKg + propellantMassKg * (1 - t / motor.burnTimeS)
      : dryMassKg;

    const thrust = burning ? motor.avgThrustN : 0;
    const weight = massKg * G;
    const netForce = thrust - weight;
    const acceleration = netForce / massKg;

    samples.push({
      t: Number(t.toFixed(2)),
      altitude: Math.max(altitude, 0),
      velocity,
      acceleration,
    });

    if (Math.abs(acceleration) > Math.abs(maxAcceleration)) maxAcceleration = acceleration;
    if (velocity > maxVelocity) maxVelocity = velocity;
    if (altitude > apogee.altitude) apogee = { t, altitude };
    if (!burnoutSample && t >= motor.burnTimeS) {
      burnoutSample = { t, altitude, velocity };
    }

    velocity += acceleration * DT;
    altitude += velocity * DT;
    t += DT;

    // Stop once the rocket has come back down after apogee.
    if (t > motor.burnTimeS && altitude <= 0 && velocity < 0) {
      samples.push({ t: Number(t.toFixed(2)), altitude: 0, velocity, acceleration });
      break;
    }
  }

  return {
    samples,
    apogee,
    maxVelocity,
    maxAcceleration,
    burnout: burnoutSample,
    flightTime: samples[samples.length - 1]?.t ?? 0,
  };
}
