// Aero currently answers from a small local knowledge base plus read-only
// awareness of the current project (Section 23 of the brief). This keeps
// the app fully functional with zero backend and no exposed API key.
//
// To upgrade Aero to a real model later (Section 24):
//   Aero UI -> project context -> AI backend/API layer -> AI model
// `buildAeroPrompt` below already assembles that context payload — swap
// `answerAero` for a call to your backend layer and pass this payload
// along, without touching the chat UI.

const TOPICS = [
  {
    match: ["stability", "stable", "margin", "caliber"],
    answer: ({ analysis }) => {
      const s = analysis.stability;
      const margin = s.marginCalibers.toFixed(2);
      return (
        `**What is it?**\nStability margin is the distance between your rocket's center of pressure (where aerodynamic force acts) and its center of gravity (where its mass balances), measured in body diameters ("calibers").\n\n` +
        `**Why does it matter?**\nA stable rocket needs the center of pressure behind the center of gravity, so it weathercocks back into straight flight instead of tumbling.\n\n` +
        `**In your project**\nYour current design has a margin of about ${margin} calibers, which reads as "${s.rating}". A margin of roughly 1-2 calibers is the usual target — much less and the rocket may be unstable, much more and it becomes overly sensitive to wind.`
      );
    },
  },
  {
    match: ["mass", "weight", "heavy", "light"],
    answer: ({ analysis }) => {
      const m = analysis.mass;
      return (
        `**What is it?**\nTotal mass is the sum of every component: nose cone, body tube, fins, motor, and avionics.\n\n` +
        `**Why does it matter?**\nMore mass means the motor has to work harder to accelerate the rocket, which lowers altitude and reduces stability margin.\n\n` +
        `**In your project**\nYour rocket currently comes to about ${Math.round(m.totalG)} g total.`
      );
    },
  },
  {
    match: ["cost", "price", "expensive", "budget"],
    answer: ({ analysis }) => {
      const c = analysis.cost;
      return (
        `**What is it?**\nEstimated cost adds up the price of every component in your current design.\n\n` +
        `**Why does it matter?**\nSwapping to a smaller motor or a lighter fin material is often the fastest way to bring the total down.\n\n` +
        `**In your project**\nYour current build comes to about $${c.totalUSD.toFixed(2)}.`
      );
    },
  },
  {
    match: ["fin", "fins"],
    answer: () =>
      `**What is it?**\nFins are the flat surfaces near the tail that keep a rocket pointed the right way in flight.\n\n` +
      `**Why does it matter?**\nBigger fins add more stability but also more drag and weight — it's a balance, not a "bigger is always better" part.\n\n` +
      `**In your project**\nOpen the Components section and click any fin set to see its root chord, span, and sweep, and how those feed into your stability margin.`,
  },
  {
    match: ["nose", "nosecone", "nose cone"],
    answer: () =>
      `**What is it?**\nThe nose cone is the forward tip of the rocket, shaped to move air around the airframe efficiently.\n\n` +
      `**Why does it matter?**\nShape affects drag at different speeds — an ogive is a good all-rounder, elliptical shapes are gentler at low speed, and conic shapes are simplest to build.\n\n` +
      `**In your project**\nYou can swap nose shapes from the Components tab; the 3D model and stability numbers update immediately.`,
  },
  {
    match: ["motor", "engine", "thrust", "impulse"],
    answer: ({ design }) =>
      `**What is it?**\nThe motor provides thrust for a short burn — typically well under 3 seconds for the model motors in the catalog.\n\n` +
      `**Why does it matter?**\nA motor's letter class (A, B, C, D...) roughly doubles total impulse each step up, so it has a big effect on altitude and on how much thrust the airframe has to survive.\n\n` +
      `**In your project**\nYou're currently using a ${design.motor.name} motor, averaging ${design.motor.avgThrustN} N of thrust over a ${design.motor.burnTimeS}s burn.`,
  },
  {
    match: ["warning", "why am i getting", "issue", "problem", "wrong"],
    answer: ({ analysis }) => {
      const s = analysis.stability;
      if (s.rating === "unstable") {
        return `Your current design shows a negative or very small stability margin, which means the center of pressure is at or ahead of the center of gravity. Try a larger fin set, a shorter/lighter nose cone, or moving the motor further aft — all of these shift the balance toward stable flight.`;
      }
      if (s.rating === "marginal") {
        return `Your stability margin is positive but under 1 caliber, which AeroForge flags as marginal. It may still fly, but a slightly larger fin set would give you more margin for error in windy conditions.`;
      }
      if (s.rating === "overstable") {
        return `Your stability margin is quite large (above 2.5 calibers). That's safe, but an overstable rocket "weathercocks" hard into the wind, which can shorten your altitude and send it off at an angle. Slightly smaller fins would loosen that up.`;
      }
      return `I don't see any active warnings on your current design — its stability margin is in the recommended 1-2.5 caliber range.`;
    },
  },
  {
    match: ["altitude", "how high", "apogee"],
    answer: () =>
      `**What is it?**\nApogee is the highest point of the flight, right before the rocket starts falling back down.\n\n` +
      `**Why does it matter?**\nIt's the number most people compare designs by — driven mostly by total impulse, mass, and drag.\n\n` +
      `**In your project**\nHead to the Simulation tab and run a flight — it'll compute your projected altitude, velocity, and flight time from your current design.`,
  },
  {
    match: ["what is aeroforge", "what can you do", "help", "features"],
    answer: () =>
      `AeroForge lets you design a model rocket in Forge, see it update live in 3D, get plain-language engineering analysis, browse and compare real components, simulate the flight, and learn the concepts behind all of it — all saved locally in your browser. Ask me about any part of that, or about a specific concept like "stability" or "fins".`,
  },
];

const FALLBACK =
  "I don't have a canned answer for that yet — try asking about stability, mass, cost, fins, nose cones, motors, or altitude, or open the Learn section for structured lessons.";

export function answerAero(question, context) {
  const q = question.toLowerCase();
  const topic = TOPICS.find((t) => t.match.some((kw) => q.includes(kw)));
  if (!topic) return FALLBACK;
  try {
    return topic.answer(context);
  } catch {
    return FALLBACK;
  }
}

// Context payload shape for a future real AI backend (Section 24).
export function buildAeroPrompt(question, { design, analysis }) {
  return {
    question,
    project: {
      name: design.name,
      nose: design.nose.name,
      body: `${design.body.name}, ${design.bodyLengthCm} cm`,
      fins: `${design.finCount}x ${design.fins.name}`,
      motor: design.motor.name,
      avionics: design.avionics.name,
      massG: Math.round(analysis.mass.totalG),
      costUSD: Number(analysis.cost.totalUSD.toFixed(2)),
      stabilityCalibers: Number(analysis.stability.marginCalibers.toFixed(2)),
      stabilityRating: analysis.stability.rating,
    },
  };
}
