// Simplified Barrowman-style stability estimate, plus mass and cost rollups.
// This is intentionally a simplified version of the real Barrowman equations
// (constant nose normal-coefficient slope, a single fin-set CP term) so that
// the numbers stay explainable to a beginner while still being grounded in
// real rocketry engineering rather than an arbitrary score.

const NOSE_CP_FACTOR = {
  conic: 0.666,
  ogive: 0.5,
  elliptical: 0.5,
};

export function computeMass(design) {
  const nose = design.nose.massG;
  const body = design.body.massPerCmG * design.bodyLengthCm;
  const fins = design.fins.massG;
  const motor = design.motor.massG;
  const avionics = design.avionics.massG;
  const paintG = 6; // small fixed allowance for paint/finish
  const totalG = nose + body + fins + motor + avionics + paintG;
  return {
    noseG: nose,
    bodyG: body,
    finsG: fins,
    motorG: motor,
    avionicsG: avionics,
    paintG,
    totalG,
  };
}

export function computeCost(design) {
  const nose = design.nose.price;
  const body = design.body.pricePerCm * design.bodyLengthCm;
  const fins = design.fins.price;
  const motor = design.motor.price;
  const avionics = design.avionics.price;
  const total = nose + body + fins + motor + avionics;
  return {
    noseUSD: nose,
    bodyUSD: body,
    finsUSD: fins,
    motorUSD: motor,
    avionicsUSD: avionics,
    totalUSD: total,
  };
}

// All lengths in cm along the airframe, measured from the nose tip.
export function computeStability(design) {
  const { nose, fins, bodyLengthCm, finCount, motor } = design;
  const diameterCm = design.body.diameterM * 100;
  const noseLengthCm = nose.lengthCm;

  // --- Center of Pressure (simplified Barrowman) -----------------
  const noseCn = 2;
  const noseCp = noseLengthCm * (NOSE_CP_FACTOR[nose.shape] ?? 0.5);

  const finRootAtBody = noseLengthCm + bodyLengthCm - fins.rootChordCm; // fins mounted at the aft end
  const Rr = fins.rootChordCm;
  const Rt = fins.tipChordCm;
  const Fs = fins.spanCm;
  const sweep = fins.sweepCm;

  const finCn =
    (1 + diameterCm / 2 / (Fs + diameterCm / 2)) *
    ((4 * finCount * Math.pow(Fs / diameterCm, 2)) /
      (1 + Math.sqrt(1 + Math.pow((2 * Fs) / (Rr + Rt), 2))));

  const finCp =
    finRootAtBody +
    (sweep / 3) * ((Rr + 2 * Rt) / (Rr + Rt)) +
    (1 / 6) * (Rr + Rt - (Rr * Rt) / (Rr + Rt));

  const totalCn = noseCn + finCn;
  const cpFromTip = (noseCn * noseCp + finCn * finCp) / totalCn;

  // --- Center of Gravity (mass-weighted) --------------------------
  const mass = computeMass(design);
  const noseCg = noseLengthCm * 0.6;
  const bodyCg = noseLengthCm + bodyLengthCm / 2;
  const finsCg = finRootAtBody + Rr * 0.4;
  const motorCg = noseLengthCm + bodyLengthCm - 5; // motor sits near the very aft end
  const avionicsCg = noseLengthCm + bodyLengthCm * 0.3; // typically mounted upper-body

  const cgFromTip =
    (mass.noseG * noseCg +
      mass.bodyG * bodyCg +
      mass.finsG * finsCg +
      mass.motorG * motorCg +
      mass.avionicsG * avionicsCg) /
    mass.totalG;

  const marginCalibers = (cpFromTip - cgFromTip) / diameterCm;

  let rating = "unstable";
  if (marginCalibers >= 1 && marginCalibers <= 2.5) rating = "ideal";
  else if (marginCalibers > 0 && marginCalibers < 1) rating = "marginal";
  else if (marginCalibers > 2.5) rating = "overstable";

  return {
    cpFromTip,
    cgFromTip,
    marginCalibers,
    rating,
    totalLengthCm: noseLengthCm + bodyLengthCm,
    diameterCm,
    thrustToWeightRatio: (motor.avgThrustN / ((mass.totalG / 1000) * 9.81)).toFixed(1),
  };
}

export function runAnalysis(design) {
  return {
    mass: computeMass(design),
    cost: computeCost(design),
    stability: computeStability(design),
  };
}
