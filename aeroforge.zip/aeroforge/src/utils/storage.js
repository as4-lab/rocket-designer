// All AeroForge data lives in the browser (Section 26-27 of the brief) —
// no accounts, no server. These helpers wrap localStorage with JSON
// encode/decode and safe fallbacks.

const PROJECTS_KEY = "aeroforge.projects";
const PROFILE_KEY = "aeroforge.profile";

function read(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function write(key, value) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage full or unavailable — fail silently, nothing is lost that
    // wasn't already lost.
  }
}

export function loadProjects() {
  return read(PROJECTS_KEY, []);
}

export function saveProject(project) {
  const projects = loadProjects();
  const idx = projects.findIndex((p) => p.id === project.id);
  const now = new Date().toISOString();
  const next = { ...project, updatedAt: now, createdAt: project.createdAt ?? now };
  if (idx >= 0) {
    projects[idx] = next;
  } else {
    projects.push(next);
  }
  write(PROJECTS_KEY, projects);
  return next;
}

export function deleteProject(id) {
  const projects = loadProjects().filter((p) => p.id !== id);
  write(PROJECTS_KEY, projects);
}

export function loadProfile() {
  return read(PROFILE_KEY, { nickname: "", avatar: "🚀" });
}

export function saveProfile(profile) {
  write(PROFILE_KEY, profile);
}
