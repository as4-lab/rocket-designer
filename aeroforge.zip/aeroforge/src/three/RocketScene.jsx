import React, { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Environment, ContactShadows } from "@react-three/drei";
import Rocket from "./Rocket.jsx";

export default function RocketScene({ design, interactive = true, spin = true }) {
  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [1.6, 0.2, 1.6], fov: 40 }}
      gl={{ antialias: true }}
    >
      <ambientLight intensity={0.5} />
      <directionalLight
        position={[2, 3, 2]}
        intensity={1.4}
        castShadow
        shadow-mapSize={[1024, 1024]}
      />
      <directionalLight position={[-2, 1, -1]} intensity={0.35} color="#c97d45" />

      <Suspense fallback={null}>
        <Rocket design={design} spin={spin} />
        <Environment preset="city" />
        <ContactShadows position={[0, -0.9, 0]} opacity={0.35} scale={4} blur={2.4} far={1.2} />
      </Suspense>

      {interactive && (
        <OrbitControls
          enablePan={false}
          minDistance={0.8}
          maxDistance={4}
          autoRotate={false}
        />
      )}
    </Canvas>
  );
}
