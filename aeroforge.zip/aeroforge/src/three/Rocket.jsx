import React, { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

// All incoming lengths are in centimeters (matching the analysis module);
// the scene itself is built in meters.
const CM = 0.01;

function useFinGeometry(fins, thicknessMm) {
  return useMemo(() => {
    const { rootChordCm: Rr, tipChordCm: Rt, spanCm: Fs, sweepCm: sweep } = fins;
    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.lineTo(0, -Rr * CM);
    shape.lineTo(Fs * CM, -(sweep + Rt) * CM);
    shape.lineTo(Fs * CM, -sweep * CM);
    shape.closePath();
    const geometry = new THREE.ExtrudeGeometry(shape, {
      depth: (thicknessMm / 10) * CM,
      bevelEnabled: false,
    });
    geometry.translate(0, 0, (-(thicknessMm / 10) * CM) / 2);
    return geometry;
  }, [fins, thicknessMm]);
}

export default function Rocket({ design, spin = true }) {
  const group = useRef();

  const diameterM = design.body.diameterM;
  const radiusM = diameterM / 2;
  const noseLengthM = design.nose.lengthCm * CM;
  const bodyLengthM = design.bodyLengthCm * CM;
  const totalLengthM = noseLengthM + bodyLengthM;

  const bodyCenterY = -totalLengthM / 2 + bodyLengthM / 2;
  const noseCenterY = -totalLengthM / 2 + bodyLengthM + noseLengthM / 2;

  const finRootAtBodyCm = design.nose.lengthCm + design.bodyLengthCm - design.fins.rootChordCm;
  const finGroupY = totalLengthM / 2 - finRootAtBodyCm * CM;

  const finGeometry = useFinGeometry(design.fins, design.fins.thicknessMm);

  const finAngles = useMemo(() => {
    const n = design.finCount;
    return Array.from({ length: n }, (_, i) => (i * (Math.PI * 2)) / n);
  }, [design.finCount]);

  useFrame((_, delta) => {
    if (spin && group.current) {
      group.current.rotation.y += delta * 0.25;
    }
  });

  const bodyMaterialProps = {
    color: design.color,
    roughness: design.finish === "glossy" ? 0.25 : 0.75,
    metalness: design.finish === "glossy" ? 0.35 : 0.05,
  };

  return (
    <group ref={group}>
      {/* Body tube */}
      <mesh position={[0, bodyCenterY, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[radiusM, radiusM, bodyLengthM, 32]} />
        <meshStandardMaterial {...bodyMaterialProps} />
      </mesh>

      {/* Nose cone */}
      <mesh position={[0, noseCenterY, 0]} castShadow>
        <coneGeometry
          args={[
            radiusM,
            noseLengthM,
            32,
            1,
            false,
            0,
            design.nose.shape === "elliptical" ? Math.PI * 2 * 0.999 : Math.PI * 2,
          ]}
        />
        <meshStandardMaterial color={design.color} roughness={0.4} metalness={0.1} />
      </mesh>

      {/* Fin ring */}
      <group position={[0, finGroupY, 0]}>
        {finAngles.map((angle, i) => (
          <group key={i} rotation={[0, angle, 0]}>
            <mesh geometry={finGeometry} position={[radiusM, 0, 0]} castShadow>
              <meshStandardMaterial color="#3a3b40" roughness={0.6} />
            </mesh>
          </group>
        ))}
      </group>

      {/* Motor nozzle nub */}
      <mesh position={[0, -totalLengthM / 2 - 0.01, 0]}>
        <cylinderGeometry args={[radiusM * 0.4, radiusM * 0.6, 0.02, 16]} />
        <meshStandardMaterial color="#1a1a1c" roughness={0.4} metalness={0.4} />
      </mesh>
    </group>
  );
}
