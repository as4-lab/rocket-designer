import React, { useState, useRef, useEffect } from "react";
import { useProject } from "../context/ProjectContext.jsx";
import { answerAero } from "../utils/aeroKnowledge.js";
import "./AeroChat.css";

export default function AeroChat() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([
    {
      role: "aero",
      text: "Hi, I'm Aero! Ask me about rocket concepts, AeroForge features, or why your current design looks the way it does.",
    },
  ]);
  const { design, analysis } = useProject();
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, open]);

  const send = (e) => {
    e.preventDefault();
    const text = input.trim();
    if (!text) return;
    const userMsg = { role: "user", text };
    const reply = { role: "aero", text: answerAero(text, { design, analysis }) };
    setMessages((m) => [...m, userMsg, reply]);
    setInput("");
  };

  return (
    <div className="aero-root">
      {open && (
        <div className="aero-panel card">
          <div className="aero-header">
            <div className="aero-header-title">
              <span className="aero-avatar">🧑‍🚀</span>
              <div>
                <div className="aero-name">Aero</div>
                <div className="aero-status">Your rocketry teacher</div>
              </div>
            </div>
            <button className="btn-ghost" onClick={() => setOpen(false)} aria-label="Close Aero">
              ✕
            </button>
          </div>

          <div className="aero-messages" ref={scrollRef}>
            {messages.map((m, i) => (
              <div key={i} className={`aero-msg aero-msg-${m.role}`}>
                {m.text}
              </div>
            ))}
          </div>

          <form className="aero-input-row" onSubmit={send}>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask Aero something…"
              aria-label="Message Aero"
            />
            <button type="submit" className="btn btn-primary">
              Send
            </button>
          </form>
        </div>
      )}

      <button
        className="aero-launcher"
        onClick={() => setOpen((o) => !o)}
        aria-label="Open Aero assistant"
      >
        🧑‍🚀
      </button>
    </div>
  );
}
