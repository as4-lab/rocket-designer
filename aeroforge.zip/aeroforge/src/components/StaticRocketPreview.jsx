import React from "react";

// A cheap SVG silhouette used on project cards, per the brief's "static
// lightweight preview" requirement — the full interactive 3D model only
// renders once a project is opened in Forge.
export default function StaticRocketPreview({ design, width = 120, height = 160 }) {
  const color = design.color ?? "#c97d45";
  const finCount = design.finCount ?? 3;

  return (
    <svg viewBox="0 0 120 160" width={width} height={height} aria-hidden="true">
      <polygon points="60,6 40,54 80,54" fill={color} />
      <rect x="40" y="54" width="40" height="70" fill={color} opacity="0.92" />
      <polygon points="40,104 24,132 40,124" fill="#3a3b40" />
      <polygon points="80,104 96,132 80,124" fill="#3a3b40" />
      {finCount === 4 && <polygon points="52,120 60,140 68,120" fill="#3a3b40" opacity="0.7" />}
      <rect x="46" y="124" width="28" height="10" rx="2" fill="#1a1a1c" />
    </svg>
  );
}
