// Structured lessons (Section 19) plus the contextual lessons linked to
// from component detail panels and Forge warnings, so both entry points
// land on real content.

export const LEARNING_PATH = [
  { id: "rocket-basics", title: "Rocket Basics", summary: "What a model rocket is made of, and how it flies." },
  { id: "aerodynamics", title: "Aerodynamics", summary: "Drag, stability, and why shape matters." },
  { id: "structures", title: "Structures", summary: "Body tubes, materials, and building for the loads involved." },
  { id: "electronics", title: "Electronics", summary: "Sensors, altimeters, and onboard data." },
  { id: "flight-computers", title: "Flight Computers", summary: "Motors, ignition, and recovery timing." },
  { id: "simulation", title: "Simulation", summary: "Reading a simulated flight, and what it can't tell you." },
];

export const LESSONS = {
  "rocket-basics": {
    title: "Rocket Basics",
    body: [
      "A model rocket is built from five main parts: a nose cone, a body tube, fins, a motor, and (optionally) avionics.",
      "The motor burns for a short time — often under three seconds — and pushes the rocket upward. After burnout, the rocket coasts upward under its own momentum until gravity brings it back down.",
      "Everything else in AeroForge — mass, cost, stability, and simulated flight — comes from how these five parts are chosen and sized.",
    ],
  },
  "aerodynamics": {
    title: "Aerodynamics",
    body: [
      "Two ideas drive most of a rocket's aerodynamic behavior: drag, which slows the rocket down, and stability, which keeps it pointed the right way.",
      "Stability comes from the relationship between the center of pressure (where aerodynamic force effectively acts) and the center of gravity (where the rocket's mass balances). For stable flight, the center of pressure needs to sit behind the center of gravity.",
      "AeroForge estimates this using a simplified version of the Barrowman equations — the same method used by most hobby rocketry design software — and reports the result in \"calibers\" (body diameters of separation).",
    ],
  },
  "aerodynamics-nose-shapes": {
    title: "Nose Cone Shapes",
    body: [
      "Nose cone shape changes how air flows around the front of the rocket.",
      "A conic nose is the simplest shape to build and works fine at low speeds, but has more drag at higher speeds than a curved profile.",
      "An ogive nose curves smoothly to a point and is the most common all-around choice on mid-power rockets.",
      "An elliptical nose is blunt and rounded — it has the lowest drag at low subsonic speeds, which is exactly the regime most model rockets fly in.",
    ],
  },
  "aerodynamics-fins": {
    title: "Fins and Stability",
    body: [
      "Fins generate a corrective aerodynamic force whenever the rocket tips away from straight flight, which is what keeps it pointed the right way.",
      "Larger fins (more span, more root chord) move the center of pressure further aft and add more stability margin — but they also add mass and drag.",
      "AeroForge computes an approximate center of pressure from your fin geometry and body diameter, and compares it against your center of gravity to report a stability margin in calibers.",
    ],
  },
  "structures": {
    title: "Structures",
    body: [
      "The body tube is the rocket's main structural spine — it has to survive the acceleration of launch, the aerodynamic loads of flight, and the shock of parachute deployment.",
      "Material affects both mass and durability: cardboard tubes are light and inexpensive but more fragile; fiberglass is heavier and stiffer, and handles higher-power motors and rougher landings.",
    ],
  },
  "structures-body-tubes": {
    title: "Body Tubes",
    body: [
      "Body tube diameter sets how much room you have for a motor and any avionics, and directly affects your stability margin (which is measured in tube diameters, or \"calibers\").",
      "A longer body tube adds mass but also gives fins more leverage further from the center of gravity, which can help or hurt stability depending on where mass is concentrated.",
    ],
  },
  "electronics": {
    title: "Electronics",
    body: [
      "Onboard electronics — most commonly an altimeter — let you record data from a flight instead of relying on watching it by eye.",
      "A basic altimeter records peak altitude. More advanced units add velocity, acceleration, and GPS tracking to help you find the rocket after it lands.",
    ],
  },
  "electronics-flight-computers": {
    title: "Flight Computers",
    body: [
      "A flight computer combines sensors (usually a barometric pressure sensor, sometimes an accelerometer) with simple onboard logic to record — and on more advanced units, react to — what's happening during flight.",
      "For beginners, a basic altimeter is a great first step: it adds a small amount of mass and cost in exchange for a real number to compare between flights.",
    ],
  },
  "flight-computers": {
    title: "Flight Computers",
    body: [
      "In full-scale and high-power rocketry, \"flight computer\" usually also covers motor ignition and parachute deployment timing — concepts AeroForge introduces here in a simplified, educational form.",
    ],
  },
  "flight-computers-motors": {
    title: "Motors",
    body: [
      "Model rocket motors are classified by letter (A, B, C, D...) where each letter roughly doubles the total impulse of the one before it.",
      "Total impulse (in Newton-seconds) is the total \"push\" a motor delivers over its burn. Average thrust and burn time both factor into how hard the rocket accelerates off the pad.",
      "A bigger motor isn't automatically better — it needs to suit the mass and structural strength of the rocket it's flying in.",
    ],
  },
  "simulation": {
    title: "Simulation",
    body: [
      "AeroForge's Version 1 simulation models thrust, gravity, and the rocket's mass decreasing as propellant burns — enough to get a reasonable altitude and velocity estimate for a first design.",
      "It does not yet include air resistance (drag), wind, or the parachute descent phase in detail — those arrive in later simulation versions, and until then, real flights will fly a bit lower and slower than the simulation predicts.",
    ],
  },
};
